@extends('layouts.dashboard')

@section('all_requests','active')
@section("title", "كافة طلبات ")



@section('css')

<style>


.img {
    border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  display: block;
  margin-left: auto;
  margin-right: auto;

}

</style>
<link rel="stylesheet" href="{{ asset('assets/vendor/animate-css/vivify.min.css')}}">
<link rel="stylesheet" href="{{ asset('assets/vendor/light-gallery/css/lightgallery.css')}}">
<link rel="stylesheet" href="{{asset('assets/vendor/sweetalert/sweetalert.css')}}" />
<link href="{{ asset('assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css') }}" rel="stylesheet">
<link href="{{ asset('assets/vendor/jquery-datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css') }}" rel="stylesheet">
<link href="{{ asset('assets/vendor/jquery-datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css') }}" rel="stylesheet">
<!-- MAIN CSS -->
@endsection
@if(auth::user()->isSuperAdmin()== true)

@section('btn')
<div class="col-md-6 col-sm-12 text-right">
    <a class="btn btn-sm btn-primary ml-2 mb-2" href='{{route("admin.requests.create")}}' title=" إضافة طلب ">
        <i class="icon-book-open mr-2"></i>إضافة طلب
    </a>




</div>

<br>


@endsection
@endif
@section("content")


@if (session('message'))
<div class="alert alert-success">

    {{session('message')}}
</div>
@endif


<div class="row clearfix">
    <div class="col-lg-12">
        <div class="card">
            <div class="table-responsive">

                <table class="table table-hover js-basic-example dataTable table-custom spacing8" id="m_table_1">

                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th class="text-center">صورة المنتج </th>
                            <th class="text-center"> المقاس </th>
                            <th class="text-center"> لون التيشرت</th>
                            <!--<th class="text-center"> لون الفينيل</th>-->
                            <!--<th class="text-center">رمز الفينيل</th>-->
                            <!--<th class="text-center">نوع الفينيل</th>-->
                            <th class="text-center"> ملف التصميم</th>

                            <th width="13%"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0 ?>
                        @foreach($all_requests as $req)


                        <tr>
                            <td class="text-center"><?= ++$i ?></td>
                            <td class="text-center"><a target="_blank"
                                       href="/storage/{{ $req->image }}">
                                       <img src="{{asset('storage/' . $req->image )}}" class="img" height="55" width="70">

                                    </a>
                                </td>

                            <td class="text-center">{{$req->size}}</td>
                            <td class="text-center">{{$req->color_t}}</td>
                            <!--<td class="text-center">{{$req->color_v}}</td>-->
                            <!--<td class="text-center">{{$req->code_v}}</td>-->
                            <!--<td class="text-center">{{$req->type_v}}</td>-->
                            <td class="text-center">{{$req->original_name}}</td>

                            <td>


                                <div class="btn-group" role="group" aria-label="Basic example">

                                <a href="{{asset('storage/files/' . $req->filePath )}}"
                                       download="{{$req->original_name}}" title="تحميل">
                                        <button type="button" class="btn btn-sm btn-info ml-2">
                                            <i class="fa fa-download"></i>
                                        </button>
                                    </a>
                                @if(auth::user()->isSuperAdmin()== true)
                                    
                                    
                                    <a class="btn btn-sm bg-blush ml-2" href='{{route("admin.requests.vinyl", [ "id" => $req->id ])}}'     title=" إضافة فينيل">
                                        <i class='fa fa-tasks'></i>
                                    </a>

                                    <a class="btn btn-sm btn-primary ml-2" href='{{route("admin.requests.edit", [ "id" => $req->id ])}}' title="تعديل الطلب">
                                        <i class='fa fa-edit'></i>
                                    </a>


                                    <button type="submit" class="btn btn-sm btn-danger ml-2 " onclick="deleteItem({{ $req->id }})" title="حذف الطلب" > 
                                    <i class='fa fa-trash'></i>
                                    </button>
                                @endif

                                </div>


                            </td>

                        </tr>
                        @endforeach
                    </tbody>
                </table>












            </div>
        </div>
    </div>
</div>















@endsection







@section("js")
<script src="{{asset('assets/vendor/jquery-validation/jquery.validate.js')}}"></script>

<!-- Jquery Validation Plugin Css -->
<!-- data table js -->
<script src="{{ asset('assets/bundles/datatablescripts.bundle.js') }}"></script>
<script src="{{asset('assets/vendor/sweetalert/sweetalert.min.js')}}"></script>
<script src="{{asset('assets/js/pages/ui/dialogs.js')}}"></script>


<script>
    $(document).ready(function() {




        var table = $('#m_table_1').DataTable({

            "language": {
                "url": "{{asset('assets/arabic.json')}}"
            },

            "columnDefs": [{
                "targets": 5,
                "orderable": false
            }]
        });
    });
</script>
<script>
    function deleteItem(id) {

        var url = '{{URL::to("/admin/requests")}}';
        var m_url = url + "/delete/"+ id;

        swal({
            title: "هل أنت متأكد  ؟",
            text: " ",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#dc3545",
            confirmButtonText: "تأكيد",
            cancelButtonText: "إلغاء",
            closeOnConfirm: false,
            closeOnCancel: true
        }, function(isConfirm) {
            if (isConfirm) {

                $.ajax({
                    async: false,
                    dataType: "json",
                    url: m_url,
                    type: 'GET',
                    success: function(data) {
                        //getAll();
                        if (data.msg == 'success') {
                            swal(" حذف !", "تم الحذف بنجاح", "success");
                            location.reload(true);
                        } else {
                            swal("خطأ !", "يرجى مراجعة الإدارة", "error");

                        }

                    },
                    error: function(er) {
                        swal("إلغاء", "يرجى مراجعة الإدارة", "error");
                    }
                })



            } else {}
        });
    }

</script>

@endsection
